import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
//�޸���Ϣ�ĶԻ���
public class ModifyDialog extends  JDialog implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//���
    private JLabel lbMsg=new JLabel("�����˺�Ϊ��");
    private JLabel accountJLabel=new JLabel(information.account);
    private JLabel password1JLabel=new JLabel("������������");
    private JPasswordField password1JPasswordField=new JPasswordField(information.password,10);
    private JLabel password2JLabel=new JLabel("����ȷ������");
    private JPasswordField password2JPasswordField=new JPasswordField(information.password,10);
    private JLabel nameJLabel=new JLabel("�����޸��ǳ�");
    private JTextField nameJTextField=new JTextField(information.name,10);
    private JButton modifyJButton=new JButton("�޸�");
    private JButton btExit=new JButton("�ر�");
    public ModifyDialog(JFrame frm) {
    //����
        super(frm,true);
        this.setBackground(Color.blue);
        this.setLayout(new GridLayout(6,2));
        this.add(lbMsg);
        this.add(accountJLabel);
        this.add(password1JLabel);
        this.add(password1JPasswordField);
        this.add(password2JLabel);
        this.add(password2JPasswordField);
        this.add(nameJLabel);
        this.add(nameJTextField);
        this.add(modifyJButton);
        this.add(btExit);		
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
        modifyJButton.addActionListener(this);
        btExit.addActionListener(this);
        this.setResizable(false);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==modifyJButton) {//������������Ƿ���ͬ
           // String password=new String(password.getPassword());
            String password1=new String(password1JPasswordField.getPassword());
            String password2=new String(password2JPasswordField.getPassword());
            if(!password1.equals(password2)) {
                JOptionPane.showMessageDialog(this,"�������벻��ͬ������������");
                return;
            }
            //String name=name.getText();
            String name=nameJTextField.getText();
            //�޸ı���
            information.password=password1;
            information.name=name;
            FileOperation.updateCustomer(information.account,password1,name);//
            JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
        }
        else {
            this.dispose();
        }
    }
}