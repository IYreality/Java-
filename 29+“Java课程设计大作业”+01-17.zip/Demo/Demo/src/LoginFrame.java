import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JTextField;

public class LoginFrame extends JFrame implements ActionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private Icon welcomeIcon=new ImageIcon("welcome.png");
    private JLabel welcomeJLabel=new JLabel(welcomeIcon);
    private JLabel accountJLabel=new JLabel("�������˺�");
    private JTextField accountJTextField=new JTextField(10);
    private JLabel passwordJLabel=new JLabel("����������");
    private JPasswordField passwordJPasswordField=new JPasswordField(10);//��*�����������������������
    private JButton loginJButton=new JButton("��¼");
    private JButton registerJButton=new JButton("ע��");
    private JButton exitJButton=new JButton("�˳�");
    
    public LoginFrame() {//�����ʼ��
        super("��¼"); 
        this.setBackground(Color.blue);
        this.setLayout(new FlowLayout());
        this.add(welcomeJLabel);
        this.add(accountJLabel);
        this.add(accountJTextField);
        this.add(passwordJLabel);
        this.add(passwordJPasswordField);
        this.add(loginJButton);
        this.add(registerJButton);
        this.add(exitJButton);
        this.setSize(250,200);
        this.setResizable(false);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //����button
        loginJButton.addActionListener(this);
        registerJButton.addActionListener(this);
        exitJButton.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {//���ݰ��µ�button���Ӽ���
        if(e.getSource()==loginJButton) {
            String account=accountJTextField.getText();
            String password=new String(passwordJPasswordField.getPassword());
            FileOperation.getInfoByAccount(account);
            if(information.account==null||!information.password.equals(password)) {
                JOptionPane.showMessageDialog(this,"��¼ʧ��");
                return;
            }
            JOptionPane.showMessageDialog(this,"��¼�ɹ�");
            this.dispose();
            new OperationFrame();
        }
        else if(e.getSource()==registerJButton) {
            //JOptionPane.showMessageDialog(this,"ע��ɹ�");
            this.dispose();
            new RegisterFrame();
        }
        else {
            JOptionPane.showMessageDialog(this,"�´��ټ�");
            System.exit(0);
        }
    }
}