public class information {//��Ϣ
    public static String account;
    public static String password;
    public static String name;
}
