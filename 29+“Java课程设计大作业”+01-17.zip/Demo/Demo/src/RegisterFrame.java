import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
//ע�����
public class RegisterFrame extends JFrame implements ActionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    private JLabel lbAccount=new JLabel("�������˺�");
    private JTextField tfAccount=new JTextField(10);//ÿ���û��˻�������һ��Ҫ����
    private JLabel lbPassword=new JLabel("����������");
    private JPasswordField pfPassword=new JPasswordField(10);
    private JLabel lbPassword2=new JLabel("���ظ�����");//ȷ������
    private JPasswordField pfPassword2=new JPasswordField(10);
    private JLabel lbName=new JLabel("�������ǳ�");//�ǳƿ����ظ�
    private JTextField tfName=new JTextField(10);
    private JButton btRegister=new JButton("ע��");
    private JButton btLogin=new JButton("��¼");
    private JButton btExit=new JButton("�˳�");
    
    public RegisterFrame() {//�����ʼ��
    	
        super("ע��");
        this.setBackground(Color.blue);
        this.setLayout(new FlowLayout());
        this.setSize(250,220);
        //����
        this.add(lbAccount);
        this.add(tfAccount);
        this.add(lbPassword);
        this.add(pfPassword);
        this.add(lbPassword2);
        this.add(pfPassword2);
        this.add(lbName);
        this.add(tfName);
        this.add(btRegister);
        this.add(btLogin);
        this.add(btExit);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//�رհ�ť
        this.setResizable(false);
        this.setVisible(true);//���ӻ�
        
        btLogin.addActionListener(this);
        btRegister.addActionListener(this);
        btExit.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {//���Ӽ���
    	
        if(e.getSource()==btRegister) {
            String password1=new String(pfPassword.getPassword());
            String password2=new String(pfPassword2.getPassword());
            if(!password1.equals(password2)) {
                JOptionPane.showMessageDialog(this,"�������벻��ͬ");
                return;
            }
            String account=tfAccount.getText();//����Ƿ��Ѿ�ע��
            FileOperation.getInfoByAccount(account);
            if(information.account!=null) {
                JOptionPane.showMessageDialog(this,"�û��Ѿ�ע��");
                return;
            }
           // String password=tfAccount.getText();//��������Ƿ�Ϊ��
            String name=tfName.getText();
            if(account=="" || password1=="" || password2=="" || name=="") {
		       	 JOptionPane.showMessageDialog(this,"��������������Ϣ");
		       	return;           	
            }
           	
           // String name=tfName.getText();
            FileOperation.updateCustomer(account,password1,name);
            JOptionPane.showMessageDialog(this,"ע��ɹ�");
        }
        else if(e.getSource()==btLogin) {//�����½����
            this.dispose();
            new LoginFrame();
        }
        else {//�˳�ϵͳ
            JOptionPane.showMessageDialog(this,"�´��ټ�");
            System.exit(0);
        }
    }
}