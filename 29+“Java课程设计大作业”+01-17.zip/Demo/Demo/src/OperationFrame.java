import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
//ѡ�����
public class OperationFrame extends JFrame implements ActionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    private String welcomMsg="��ѡ�����:";
    private JLabel welcomeJLabel=new JLabel(welcomMsg);
    private JButton chatJButton=new JButton("��ʼ����");
    private JButton modifyJButton=new JButton("�޸�����");
    private JButton exitJButton=new JButton("�˳�");
    public OperationFrame() {

        super(information.account);
        this.setBackground(Color.blue);
        this.setLayout(new GridLayout(4,1));
        this.add(welcomeJLabel);
        this.add(chatJButton);
        this.add(modifyJButton);
        this.add(exitJButton);
        this.setSize(300,250);
        this.setResizable(false);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        chatJButton.addActionListener(this);
        modifyJButton.addActionListener(this);
        exitJButton.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==chatJButton) {
        	try {
				new chatFrame(information.name);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
        else if(e.getSource()==modifyJButton) {
            new ModifyDialog(this);
        }
        else {
            JOptionPane.showMessageDialog(this,"�´��ټ�");
            System.exit(0);
        }
    }
}